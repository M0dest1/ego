/*
# Create leads table for EGO Fitness School lead capture

1. New Tables
- `leads`
  - id (uuid, primary key)
  - first_name (text, not null) - ім'я клієнта
  - last_name (text, not null) - прізвище клієнта
  - phone (text, not null) - номер телефону
  - location (text, not null) - обрана локація (EGO 1 / EGO 2)
  - form_type (text, not null) - тип заявки (trial / membership / school / trainer)
  - note (text) - додаткова інформація (напр. обраний абонемент або тренер)
  - created_at (timestamptz)

2. Security
- Enable RLS on `leads`.
- Grant INSERT to anon + authenticated so the public lead form can submit.
- No SELECT/UPDATE/DELETE grants for anon/authenticated — leads are private to operators.
- INSERT policy allows anyone to insert (public lead form).
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  phone text NOT NULL,
  location text NOT NULL,
  form_type text NOT NULL,
  note text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

GRANT INSERT ON leads TO anon, authenticated;

DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads" ON leads FOR INSERT
TO anon, authenticated WITH CHECK (true);
