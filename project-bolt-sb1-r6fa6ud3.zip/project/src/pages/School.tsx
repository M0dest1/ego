import { Check, Clock, GraduationCap, Award, Briefcase, FileText, ArrowRight } from 'lucide-react';
import { PageHero, SectionHeading } from '@/components/Section';
import { useLeadModal } from '@/lib/leadModal';
import { schoolCourses } from '@/lib/data';

const programSteps = [
  { icon: FileText, title: 'Онлайн-реєстрація', text: 'Заповнюєш заявку — ми передзвонюємо та консультуємо.' },
  { icon: GraduationCap, title: 'Теорія', text: 'Анатомія, біомеханіка, нутриціологія — лекції та відеоматеріали.' },
  { icon: Briefcase, title: 'Практика', text: 'Асистуєш тренерам EGO з першого тижня, ведеш клієнтів.' },
  { icon: Award, title: 'Сертифікація', text: 'Іспит + захист програми. Отримуєш диплом визнаний в Україні та ЄС.' },
];

export default function School() {
  const { open } = useLeadModal();

  return (
    <>
      <PageHero
        eyebrow="Школа тренерів"
        title={<>Стань <span className="neon-text">сертифікованим</span> інструктором</>}
        subtitle="Ліцензована школа підготовки фітнес-інструкторів від EGO Fitness School. Практика, теорія, сертифікат, працевлаштування."
      >
        <div className="flex flex-wrap justify-center gap-3">
          {[
            { icon: Clock, text: '3-5 місяців' },
            { icon: Award, text: 'Диплом державного зразка' },
            { icon: Briefcase, text: 'Працевлаштування в EGO' },
          ].map((b) => (
            <span key={b.text} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-coal-700/60 border border-white/10 text-sm text-white/75">
              <b.icon className="w-4 h-4 text-neon-300" /> {b.text}
            </span>
          ))}
        </div>
      </PageHero>

      {/* COURSES */}
      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Програми"
            title={<>Обери <span className="neon-text">свій напрям</span></>}
            subtitle="Від базової підготовки до спеціалізації у силовому коучингу."
          />
          <div className="grid gap-6 md:grid-cols-3">
            {schoolCourses.map((c) => (
              <div
                key={c.id}
                className={`card-dark p-7 flex flex-col ${c.highlight ? 'border-neon-300/50 shadow-neon-sm' : ''}`}
              >
                {c.highlight && (
                  <span className="inline-block self-start px-3 py-1 rounded-full bg-neon-300 text-coal-900 text-[10px] font-bold uppercase tracking-wider mb-3 shadow-neon">
                    Рекомендуємо
                  </span>
                )}
                <h3 className="display-text text-2xl text-white tracking-wide mb-2">{c.name}</h3>
                <p className="text-sm text-white/55 leading-relaxed mb-5">{c.description}</p>

                <div className="flex items-center justify-between mb-5 py-3 border-y border-white/5">
                  <div>
                    <div className="text-xs text-white/40 uppercase tracking-wider">Тривалість</div>
                    <div className="text-neon-300 font-semibold">{c.duration}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-white/40 uppercase tracking-wider">Вартість</div>
                    <div className="text-white font-semibold">{c.price}</div>
                  </div>
                </div>

                <ul className="space-y-2 mb-6 flex-1">
                  {c.topics.map((t) => (
                    <li key={t} className="flex items-start gap-2 text-sm text-white/65">
                      <Check className="w-4 h-4 text-neon-300 shrink-0 mt-0.5" /> {t}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => open('school', `Курс: ${c.name}`)}
                  className={c.highlight ? 'btn-neon w-full !py-2.5 text-sm' : 'btn-outline w-full !py-2.5 text-sm'}
                >
                  Подати заявку
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="section-pad bg-coal-800/40 border-y border-white/5">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Як це працює"
            title={<>Шлях від <span className="neon-text">студента до тренера</span></>}
          />
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {programSteps.map((s, i) => (
              <div key={s.title} className="relative card-dark p-6">
                <span className="absolute top-4 right-5 display-text text-5xl text-neon-300/10">0{i + 1}</span>
                <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-neon-300/10 neon-border mb-4">
                  <s.icon className="w-6 h-6 text-neon-300" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{s.title}</h3>
                <p className="text-sm text-white/55 leading-relaxed">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CERTIFICATION */}
      <section className="section-pad">
        <div className="mx-auto max-w-7xl grid gap-12 lg:grid-cols-2 items-center">
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/6339401/pexels-photo-6339401.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
              alt="Навчання в EGO School"
              className="rounded-2xl border border-neon-300/20 shadow-neon-sm object-cover h-[420px] w-full"
            />
          </div>
          <div>
            <SectionHeading
              center={false}
              eyebrow="Сертифікація"
              title={<>Диплом, що <span className="neon-text">відкриває двері</span></>}
              subtitle="Після успішної здачі іспиту ти отримуєш диплом та підтримку від мережі EGO."
            />
            <div className="space-y-4">
              {[
                'Диплом державного зразка + внутрішній сертифікат EGO',
                'Доступ до закритої спільноти випускників та mentорів',
                'Пріоритетне працевлаштування у зали EGO 1 та EGO 2',
                'Можливість проходження стажування за кордоном',
              ].map((t) => (
                <div key={t} className="flex items-start gap-3">
                  <div className="shrink-0 mt-0.5 w-5 h-5 rounded-full bg-neon-300/10 neon-border flex items-center justify-center">
                    <Check className="w-3 h-3 text-neon-300" />
                  </div>
                  <p className="text-sm text-white/70 leading-relaxed">{t}</p>
                </div>
              ))}
            </div>
            <button onClick={() => open('school')} className="btn-neon mt-8">
              <GraduationCap className="w-5 h-5" /> Подати заявку <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>
    </>
  );
}
