import { Award, Calendar, ArrowRight } from 'lucide-react';
import { PageHero } from '@/components/Section';
import { useLeadModal } from '@/lib/leadModal';
import { trainers } from '@/lib/data';

export default function Trainers() {
  const { open } = useLeadModal();

  return (
    <>
      <PageHero
        eyebrow="Тренерський склад"
        title={<>Майстри, що <span className="neon-text">ведуть до цілі</span></>}
        subtitle="Кожен тренер EGO — сертифікований спеціаліст з реальними спортивними досягненнями."
      />

      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {trainers.map((t) => (
              <div key={t.id} className="card-dark overflow-hidden group flex flex-col">
                <div className="relative h-96 overflow-hidden">
                  <img
                    src={t.image}
                    alt={t.name}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-coal-700 via-coal-700/20 to-transparent" />
                  <div className="absolute bottom-4 left-5 right-5">
                    <span className="inline-block px-3 py-1 rounded-md bg-coal-900/80 neon-border text-neon-300 text-xs font-semibold uppercase tracking-wider mb-2">
                      {t.role}
                    </span>
                    <h3 className="display-text text-2xl text-white tracking-wide">{t.name}</h3>
                    <p className="text-sm text-white/60">{t.experience}</p>
                  </div>
                </div>

                <div className="p-5 flex flex-col flex-1">
                  <div className="mb-4">
                    <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neon-300/80 mb-2">
                      <Award className="w-4 h-4" /> Досягнення
                    </div>
                    <ul className="space-y-1.5">
                      {t.achievements.map((a) => (
                        <li key={a} className="flex items-start gap-2 text-sm text-white/65">
                          <span className="text-neon-300 mt-0.5">▸</span> {a}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <button
                    onClick={() => open('trainer', `Тренер: ${t.name} (${t.role})`)}
                    className="btn-outline w-full mt-auto !py-2.5 text-sm"
                  >
                    <Calendar className="w-4 h-4" /> Записатися до тренера
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* join team */}
      <section className="section-pad bg-coal-800/40 border-t border-white/5">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="display-text text-3xl sm:text-4xl text-white tracking-wide mb-4">
            Хочеш приєднатись до <span className="neon-text">команди EGO?</span>
          </h2>
          <p className="text-white/60 mb-7">
            Ми постійно шукаємо сильних тренерів. А ще — навчаємо своїх у Школі EGO Fitness School.
          </p>
          <a href="/school" className="btn-neon">
            Подати заявку <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </section>
    </>
  );
}
