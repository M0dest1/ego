import { Link } from 'react-router-dom';
import { HeartPulse, Sparkles, Clock, ArrowRight } from 'lucide-react';
import { PageHero, SectionHeading } from '@/components/Section';
import { useLeadModal } from '@/lib/leadModal';

const services = [
  { icon: HeartPulse, title: 'Спортивний масаж', text: 'Відновлення після навантажень, зняття напруги та підготовка тіла до наступного тренування.' },
  { icon: Sparkles, title: 'Релакс-масаж', text: 'М’яке перезавантаження для тіла й нервової системи в атмосфері спокою та турботи.' },
  { icon: Clock, title: 'Масаж за записом', text: 'Обери зручний час у клубі та отримай персональну увагу фахівця без зайвого очікування.' },
];

export default function Massage() {
  const { open } = useLeadModal();

  return (
    <>
      <PageHero
        eyebrow="Масаж"
        title={<>Відновлення, що <span className="neon-text">відчувається</span></>}
        subtitle="Професійний масаж для відновлення, легкості та кращих результатів у тренуваннях."
      />

      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Наші послуги"
            title={<>Турбота про тіло після <span className="neon-text">кожного тренування</span></>}
            subtitle="Підбери формат, який відповідає твоєму ритму та самопочуттю."
          />
          <div className="grid gap-5 md:grid-cols-3">
            {services.map((service) => (
              <div key={service.title} className="card-dark p-7">
                <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-neon-300/10 neon-border mb-5">
                  <service.icon className="w-7 h-7 text-neon-300" />
                </div>
                <h3 className="display-text text-2xl text-white mb-3 tracking-wide">{service.title}</h3>
                <p className="text-sm text-white/60 leading-relaxed">{service.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden border-t border-white/5">
        <div className="absolute inset-0 bg-radial-neon" />
        <div className="relative mx-auto max-w-3xl px-5 sm:px-8 lg:px-12 py-20 text-center">
          <h2 className="display-text text-3xl sm:text-5xl text-white tracking-wide mb-4">
            Подаруй собі <span className="neon-text">відновлення</span>
          </h2>
          <p className="text-white/60 mb-7">Залиш заявку, і ми підберемо зручний час для сеансу.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => open('trial', 'Запис на масаж')} className="btn-neon">Записатись на масаж</button>
            <Link to="/contacts" className="btn-outline">Контакти <ArrowRight className="w-4 h-4" /></Link>
          </div>
        </div>
      </section>
    </>
  );
}
