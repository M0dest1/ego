import { Link } from 'react-router-dom';
import {
  Dumbbell,
  Users,
  Award,
  Zap,
  ArrowRight,
  Flame,
  Trophy,
  GraduationCap,
} from 'lucide-react';
import { useLeadModal } from '@/lib/leadModal';
import { locations, memberships, trainers } from '@/lib/data';
import { SectionHeading } from '@/components/Section';

export default function Home() {
  const { open } = useLeadModal();

  return (
    <>
      {/* HERO */}
      <section className="relative min-h-[88vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1552252/pexels-photo-1552252.jpeg?auto=compress&cs=tinysrgb&h=1080&w=1920"
            alt="Тренажерний зал EGO"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-coal-900 via-coal-900/80 to-coal-900/40" />
          <div className="absolute inset-0 bg-gradient-to-t from-coal-900 via-transparent to-coal-900/60" />
        </div>

        <div className="relative mx-auto max-w-7xl px-5 sm:px-8 lg:px-12 py-20 w-full">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 px-4 py-2 mb-6 text-xs font-semibold uppercase tracking-[0.25em] text-neon-300 neon-border rounded-full animate-pulseGlow">
              <Flame className="w-3.5 h-3.5" /> Найатмосферніші зали Вінниці
            </span>
            <h1 className="display-text text-5xl sm:text-7xl lg:text-8xl text-white leading-[0.95] tracking-wide">
              <span style={{ fontSize: '72px' }}>ТРЕНУЙСЯ, ВЧИСЬ,</span> <br />
              <span className="neon-text" style={{ fontSize: '72px' }}>БУДЬ ЗАВЖДИ В ВІДМІННІЙ ФОРМІ</span>
            </h1>
            <p className="mt-6 text-lg sm:text-xl text-white/70 max-w-xl leading-relaxed">
              Простір, де формуються сильніші тіла, професійні тренери та спільнота людей, які обирають розвиток.
            </p>
            <div className="mt-9 flex flex-col sm:flex-row gap-4">
              <button onClick={() => open('trial')} className="btn-neon text-base">
                <Zap className="w-5 h-5" /> Познайомитись з клубом
              </button>
              <Link to="/membership" className="btn-outline text-base">
                Обрати абонемент <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="mt-12 flex flex-wrap gap-x-10 gap-y-4">
              {[
                { value: '2', label: 'зали в місті' },
                { value: '18+', label: 'тренерів' },
                { value: '1300+', label: 'клієнтів' },
              ].map((s) => (
                <div key={s.label}>
                  <div className="display-text text-3xl neon-text">{s.value}</div>
                  <div className="text-sm text-white/50">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* scan line */}
        <div className="absolute bottom-0 inset-x-0 h-px overflow-hidden">
          <div className="h-full w-1/3 bg-gradient-to-r from-transparent via-neon-300 to-transparent animate-scan" />
        </div>
      </section>

      {/* MARQUEE */}
      <div className="relative overflow-hidden border-y border-white/5 bg-coal-800/50 py-4">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="flex items-center gap-8 px-4 shrink-0">
              {['СИЛА', 'ВОЛЯ', 'РЕЗУЛЬТАТ', 'АТМОСФЕРА', 'ЗНАННЯ', 'РІСТ', 'ДИСЦИПЛІНА'].map((w) => (
                <span key={w} className="display-text text-2xl text-white/15 tracking-widest flex items-center gap-8">
                  {w} <span className="text-neon-300/40">●</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* ADVANTAGES */}
      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Чому EGO"
            title={<>Переваги, що <span className="neon-text">видно одразу</span></>}
            subtitle="Ми не просто зал — ми школа сили, дисципліни та результату."
          />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Dumbbell, title: 'Різноманітне обладнання', text: 'Силові рами, кросовери, гакк-машини — топовий арсенал.' },
              { icon: Users, title: 'Команда професійних тренерів', text: 'Кожен тренер є сертифікованим, також в EGO Fitness School працюють виступаючі спортсмени.' },
              { icon: Zap, title: 'Різноманітність форматів тренувань', text: 'Працюємо як персонально, так і в групах. Силові, пілатес, бокс, фітнес, зумба і т.д.' },
              { icon: GraduationCap, title: 'Навчання та розвиток', text: 'В нашому залі ми не тільки тренуємо, а й навчаємо тренувати.' },
            ].map((a) => (
              <div key={a.title} className="card-dark p-6 group">
                <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-neon-300/10 neon-border mb-4 group-hover:shadow-neon transition-shadow">
                  <a.icon className="w-6 h-6 text-neon-300" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{a.title}</h3>
                <p className="text-sm text-white/55 leading-relaxed">{a.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TWO HALLS */}
      <section className="section-pad bg-coal-800/40 border-y border-white/5">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Наші зали"
            title={<>Дві локації — <span className="neon-text">одна якість</span></>}
            subtitle="Обери найближчий зал. Обидві точки працюють за єдиним стандартом EGO."
          />
          <div className="grid gap-6 md:grid-cols-2">
            {locations.map((loc, i) => (
              <div key={loc.id} className="group relative overflow-hidden rounded-2xl border border-white/10 hover:border-neon-300/40 transition-all duration-500">
                <div className="relative h-72 sm:h-80 overflow-hidden">
                  <img
                    src={i === 0
                      ? 'https://images.pexels.com/photos/6389516/pexels-photo-6389516.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
                      : 'https://images.pexels.com/photos/5327447/pexels-photo-5327447.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'}
                    alt={loc.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-coal-900 via-coal-900/40 to-transparent" />
                  <div className="absolute top-4 left-4 px-3 py-1.5 rounded-md bg-coal-900/80 neon-border text-neon-300 text-xs font-semibold uppercase tracking-wider">
                    {loc.name}
                  </div>
                </div>
                <div className="p-6 bg-coal-700/80">
                  <h3 className="display-text text-2xl text-white mb-1">{loc.name}</h3>
                  <p className="text-sm text-white/60 mb-4">{loc.address}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-neon-300/80">Відкрито сьогодні · 8:00 — 22:00</span>
                    <Link to="/contacts" className="text-sm font-medium text-neon-300 hover:text-neon-200 flex items-center gap-1">
                      Деталі <ArrowRight className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MEMBERSHIP PREVIEW */}
      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Абонементи"
            title={<>Тарифи під <span className="neon-text">кожну ціль</span></>}
            subtitle="Від разового візиту до безліміту на рік — обери свій темп."
          />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {memberships.slice(0, 4).map((m) => (
              <div
                key={m.id}
                className={`card-dark p-6 flex flex-col ${m.highlight ? 'border-neon-300/40 shadow-neon-sm' : ''}`}
              >
                <h3 className="display-text text-2xl text-white mb-1">{m.name}</h3>
                <p className="text-xs text-white/40 mb-4">{m.period}</p>
                <div className="display-text text-4xl neon-text mb-4">{m.price}<span className="text-lg text-white/50"> грн</span></div>
                <ul className="space-y-2 mb-5 flex-1">
                  {m.features.slice(0, 3).map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm text-white/65">
                      <span className="text-neon-300 mt-0.5">▸</span> {f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => open('membership', `Абонемент: ${m.name}`)} className="btn-outline w-full !py-2.5 text-sm">
                  Обрати
                </button>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link to="/membership" className="btn-ghost text-neon-300">
              Всі тарифи <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* TRAINERS PREVIEW */}
      <section className="section-pad bg-coal-800/40 border-y border-white/5">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Команда"
            title={<>Тренери, що <span className="neon-text">задають темп</span></>}
            subtitle="Кожен — майстер своєї справи з реальними досягненнями."
          />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {trainers.slice(0, 3).map((t) => (
              <div key={t.id} className="card-dark overflow-hidden group">
                <div className="relative h-80 overflow-hidden">
                  <img src={t.image} alt={t.name} className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-coal-700 to-transparent" />
                  <div className="absolute bottom-3 left-4">
                    <div className="text-neon-300 text-sm font-medium">{t.role}</div>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="text-lg font-semibold text-white mb-1">{t.name}</h3>
                  <p className="text-xs text-white/45 mb-3">{t.experience}</p>
                  <Link to="/trainers" className="text-sm text-neon-300 hover:text-neon-200 flex items-center gap-1">
                    Детальніше <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SCHOOL + CTA */}
      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-10 lg:grid-cols-2 items-center">
            <div>
              <span className="inline-block text-xs font-semibold uppercase tracking-[0.25em] text-neon-300 mb-3">
                EGO Fitness School
              </span>
              <h2 className="display-text text-4xl sm:text-5xl text-white tracking-wide leading-tight mb-5">
                Стань <span className="neon-text">тренером</span> EGO
              </h2>
              <p className="text-white/60 leading-relaxed mb-6">
                Школа підготовки персональних тренерів. Анатомія, біомеханіка, програмування,
                практика в залах EGO. Сертифікат по закінченню школи.
              </p>
              <div className="flex flex-wrap gap-3 mb-7">
                {[
                  { icon: GraduationCap, text: 'Сертифікація' },
                  { icon: Award, text: 'Практика з 2 тижня' },
                  { icon: Trophy, text: 'Працевлаштування' },
                ].map((b) => (
                  <span key={b.text} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-coal-700 border border-white/10 text-sm text-white/75">
                    <b.icon className="w-4 h-4 text-neon-300" /> {b.text}
                  </span>
                ))}
              </div>
              <Link to="/school" className="btn-neon">
                <GraduationCap className="w-5 h-5" /> Дізнатися про курси
              </Link>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/37677569/pexels-photo-37677569.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Школа тренерів EGO"
                className="rounded-2xl border border-neon-300/20 shadow-neon-sm object-cover h-80 w-full"
              />
              <div className="absolute -bottom-4 -left-4 px-5 py-3 rounded-xl bg-coal-900 neon-border">
                <div className="display-text text-3xl neon-text">4+</div>
                <div className="text-xs text-white/60">випусків на рік</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="relative overflow-hidden border-t border-white/5">
        <div className="absolute inset-0 bg-radial-neon" />
        <div className="relative mx-auto max-w-4xl px-5 sm:px-8 lg:px-12 py-20 lg:py-28 text-center">
          <h2 className="display-text text-4xl sm:text-6xl text-white tracking-wide leading-tight">
            Готовий розкрити <br /><span className="neon-text">своє его?</span>
          </h2>
          <p className="mt-5 text-lg text-white/60 max-w-xl mx-auto">
            Твоя історія в Ego починається сьогодні.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => open('trial')} className="btn-neon text-base">
              <Zap className="w-5 h-5" /> Записатися на перше тренування
            </button>
            <Link to="/contacts" className="btn-outline text-base">
              Контакти <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
