import { Link } from 'react-router-dom';
import { Shield, Users, Trophy, ArrowRight } from 'lucide-react';
import { PageHero, SectionHeading } from '@/components/Section';
import { useLeadModal } from '@/lib/leadModal';

const benefits = [
  { icon: Shield, title: 'Безпечний старт', text: 'Поступове навантаження та уважний супровід на кожному етапі.' },
  { icon: Users, title: 'Сильна спільнота', text: 'Тренування в середовищі підтримки, поваги та взаємної мотивації.' },
  { icon: Trophy, title: 'Нові цілі', text: 'Повернення до активного життя, сили й упевненості через рух.' },
];

export default function VeteranSport() {
  const { open } = useLeadModal();

  return (
    <>
      <PageHero
        eyebrow="Ветеранський спорт"
        title={<>Сила повертається <span className="neon-text">через рух</span></>}
        subtitle="Підтримуємо ветеранів на шляху до відновлення, нових цілей і активного життя."
      />

      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Програма підтримки"
            title={<>Тренування з повагою до <span className="neon-text">твого темпу</span></>}
            subtitle="Індивідуальний підхід, адаптовані вправи та команда, яка поруч."
          />
          <div className="grid gap-5 md:grid-cols-3">
            {benefits.map((benefit) => (
              <div key={benefit.title} className="card-dark p-7">
                <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-neon-300/10 neon-border mb-5">
                  <benefit.icon className="w-7 h-7 text-neon-300" />
                </div>
                <h3 className="display-text text-2xl text-white mb-3 tracking-wide">{benefit.title}</h3>
                <p className="text-sm text-white/60 leading-relaxed">{benefit.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden border-t border-white/5">
        <div className="absolute inset-0 bg-radial-neon" />
        <div className="relative mx-auto max-w-3xl px-5 sm:px-8 lg:px-12 py-20 text-center">
          <h2 className="display-text text-3xl sm:text-5xl text-white tracking-wide mb-4">
            Разом до <span className="neon-text">нових перемог</span>
          </h2>
          <p className="text-white/60 mb-7">Зв’яжись із нами, щоб дізнатися про умови програми.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => open('trial', 'Ветеранський спорт')} className="btn-neon">Дізнатись більше</button>
            <Link to="/contacts" className="btn-outline">Контакти <ArrowRight className="w-4 h-4" /></Link>
          </div>
        </div>
      </section>
    </>
  );
}
