import { Phone, Clock, MapPin, Instagram, Send, Facebook } from 'lucide-react';
import { PageHero, SectionHeading } from '@/components/Section';
import { useLeadModal } from '@/lib/leadModal';
import { locations, scheduleHours } from '@/lib/data';
import MapView from '@/components/MapView';

export default function Contacts() {
  const { open } = useLeadModal();

  return (
    <>
      <PageHero
        eyebrow="Контакти"
        title={<>Знайди <span className="neon-text">свій EGO</span></>}
        subtitle="Два зали на проспекті Коцюбинського. Обери найближчий — і приходь."
      />

      {/* locations + hours */}
      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-6 md:grid-cols-2 mb-12">
            {locations.map((loc) => (
              <div key={loc.id} className="card-dark p-7">
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-neon-300/10 neon-border">
                    <MapPin className="w-6 h-6 text-neon-300" />
                  </div>
                  <div>
                    <h3 className="display-text text-2xl text-white tracking-wide">{loc.name}</h3>
                    <p className="text-sm text-white/55">{loc.address}</p>
                  </div>
                </div>

                <a
                  href={`tel:${loc.phone.replace(/[^+\d]/g, '')}`}
                  className="flex items-center gap-2 text-neon-300 hover:text-neon-200 transition-colors mb-4"
                >
                  <Phone className="w-4 h-4" /> {loc.phone}
                </a>

                <div className="rounded-lg bg-coal-900/60 border border-white/5 p-4">
                  <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neon-300/80 mb-3">
                    <Clock className="w-4 h-4" /> Графік роботи
                  </div>
                  <ul className="space-y-2">
                    {scheduleHours.map((s) => (
                      <li key={s.day} className="flex items-center justify-between text-sm">
                        <span className="text-white/60">{s.day}</span>
                        <span className="text-white/85 font-medium">{s.hours}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button onClick={() => open('trial', `Локація: ${loc.name}`)} className="btn-outline w-full mt-5 !py-2.5 text-sm">
                  Записатися в {loc.name}
                </button>
              </div>
            ))}
          </div>

          {/* MAP */}
          <SectionHeading
            eyebrow="На карті"
            title={<>Інтерактивна <span className="neon-text">карта</span></>}
            subtitle="Натисни на локацію, щоб побачити її на карті та прокласти маршрут."
          />
          <MapView />
        </div>
      </section>

      {/* socials + cta */}
      <section className="section-pad bg-coal-800/40 border-t border-white/5">
        <div className="mx-auto max-w-3xl text-center">
          <SectionHeading
            eyebrow="Соцмережі"
            title={<>Слідкуй за <span className="neon-text">EGO</span></>}
            subtitle="Анонси, знижки, відео з тренувань та результати клієнтів — у наших соцмережах."
          />
          <div className="flex items-center justify-center gap-4 mb-10">
            {[
              { icon: Instagram, href: 'https://instagram.com', label: 'Instagram' },
              { icon: Send, href: 'https://t.me', label: 'Telegram' },
              { icon: Facebook, href: 'https://facebook.com', label: 'Facebook' },
            ].map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="flex items-center justify-center w-14 h-14 rounded-lg border border-white/10 text-white/70 hover:text-neon-300 hover:border-neon-300/50 hover:shadow-neon transition-all"
              >
                <Icon className="w-6 h-6" />
              </a>
            ))}
          </div>
          <button onClick={() => open('trial')} className="btn-neon">
            Записатися на пробне
          </button>
        </div>
      </section>
    </>
  );
}
