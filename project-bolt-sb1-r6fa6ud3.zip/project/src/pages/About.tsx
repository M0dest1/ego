import { Link } from 'react-router-dom';
import { Target, Eye, Heart, Award, Users, Dumbbell, Sparkles, ArrowRight } from 'lucide-react';
import { PageHero, SectionHeading } from '@/components/Section';

const values = [
  { icon: Target, title: 'Місія', text: 'Сформувати культуру сильних, дисциплінованих людей через якісний фітнес.' },
  { icon: Eye, title: 'Бачення', text: 'Стати мережею №1 у регіоні за рівнем обладнання, сервісу та підготовки тренерів.' },
  { icon: Heart, title: 'Цінності', text: 'Чесність, результат, повага до клієнта та невпинний розвиток.' },
];

const stats = [
  { value: '2018', label: 'рік заснування' },
  { value: '2', label: 'преміальні зали' },
  { value: '12+', label: 'профи-тренерів' },
  { value: '5000+', label: 'задоволених клієнтів' },
];

export default function About() {
  return (
    <>
      <PageHero
        eyebrow="Про клуб"
        title={<>Мережа <span className="neon-text">EGO Fitness</span></>}
        subtitle="Два зали, одна філософія — сила, воля, результат. Створено для тих, хто знає ціну дисципліни."
      />

      {/* STORY */}
      <section className="section-pad">
        <div className="mx-auto max-w-7xl grid gap-12 lg:grid-cols-2 items-center">
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/6389893/pexels-photo-6389893.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
              alt="Атмосфера залу EGO"
              className="rounded-2xl border border-neon-300/20 shadow-neon-sm object-cover h-[460px] w-full"
            />
            <div className="absolute -top-4 -right-4 px-6 py-4 rounded-xl bg-coal-900 neon-border">
              <div className="display-text text-4xl neon-text">2018</div>
              <div className="text-xs text-white/60">заснування мережі</div>
            </div>
          </div>
          <div>
            <SectionHeading
              center={false}
              eyebrow="Наша історія"
              title={<>З маленького залу — у <span className="neon-text">мережу</span></>}
            />
            <div className="space-y-4 text-white/65 leading-relaxed">
              <p>
                EGO Fitness School почалась з однієї мрії — створити зал, де обладнання, сервіс
                і атмосфера відповідають найвищим стандартам. У 2018 році відкрився перший зал
                на Коцюбинського, 43 — EGO 1.
              </p>
              <p>
                Через три роки, у 2021, ми відкрили другу точку — EGO 2 на проспекті Коцюбинського, 78.
                Обидва зали працюють за єдиним стандартом: преміальне обладнання, сертифіковані тренери,
                чистота та порядок.
              </p>
              <p>
                Сьогодні EGO — це не лише фітнес-клуб, а й <span className="text-neon-300">школа тренерів</span>,
                що готує інструкторів з ліцензованою сертифікацією. Ми ростимо не лише тіла, а й професіоналів.
              </p>
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/trainers" className="btn-outline !py-2.5 text-sm">Наші тренери <ArrowRight className="w-4 h-4" /></Link>
              <Link to="/equipment" className="btn-ghost text-sm">Обладнання <ArrowRight className="w-4 h-4" /></Link>
            </div>
          </div>
        </div>
      </section>

      {/* VALUES */}
      <section className="section-pad bg-coal-800/40 border-y border-white/5">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Філософія"
            title={<>Те, на чому тримається <span className="neon-text">EGO</span></>}
          />
          <div className="grid gap-5 md:grid-cols-3">
            {values.map((v) => (
              <div key={v.title} className="card-dark p-7 text-center">
                <div className="mx-auto flex items-center justify-center w-14 h-14 rounded-xl bg-neon-300/10 neon-border mb-5">
                  <v.icon className="w-7 h-7 text-neon-300" />
                </div>
                <h3 className="display-text text-2xl text-white mb-3 tracking-wide">{v.title}</h3>
                <p className="text-sm text-white/60 leading-relaxed">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="section-pad">
        <div className="mx-auto max-w-5xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((s) => (
              <div key={s.label} className="text-center p-6 rounded-xl bg-coal-700/60 border border-white/10 hover:border-neon-300/30 transition-colors">
                <div className="display-text text-5xl neon-text mb-2">{s.value}</div>
                <div className="text-sm text-white/55">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* APPROACH */}
      <section className="section-pad bg-coal-800/40 border-t border-white/5">
        <div className="mx-auto max-w-7xl grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <SectionHeading
              center={false}
              eyebrow="Наш підхід"
              title={<>Професіоналізм у <span className="neon-text">кожній деталі</span></>}
              subtitle="Від вибору обладнання до підготовки тренера — ми не залишаємо нічого на волю випадку."
            />
            <div className="space-y-5">
              {[
                { icon: Dumbbell, title: 'Топове обладнання', text: 'Силові рами, кросовери, гакк-машини, кардіо-зона — лише від перевірених брендів.' },
                { icon: Users, title: 'Команда майстрів', text: 'Тренери з реальними званнями та міжнародними сертифікатами.' },
                { icon: Award, title: 'Стандарти сервісу', text: 'Чистота, безпека, індивідуальний підхід до кожного клієнта.' },
                { icon: Sparkles, title: 'Атмосфера сили', text: 'Темний неоновий інтер\'єр, що заряджає на рекорд.' },
              ].map((item) => (
                <div key={item.title} className="flex gap-4">
                  <div className="shrink-0 flex items-center justify-center w-11 h-11 rounded-lg bg-neon-300/10 neon-border">
                    <item.icon className="w-5 h-5 text-neon-300" />
                  </div>
                  <div>
                    <h4 className="text-base font-semibold text-white mb-1">{item.title}</h4>
                    <p className="text-sm text-white/55 leading-relaxed">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img src="https://images.pexels.com/photos/2261481/pexels-photo-2261481.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Обладнання EGO" className="rounded-xl border border-white/10 h-full object-cover" />
            <img src="https://images.pexels.com/photos/14524650/pexels-photo-14524650.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Тренування EGO" className="rounded-xl border border-white/10 h-full object-cover mt-8" />
          </div>
        </div>
      </section>
    </>
  );
}
