import { useState } from 'react';
import { Clock, User, MapPin } from 'lucide-react';
import { PageHero } from '@/components/Section';
import { schedule } from '@/lib/data';
import { useLeadModal } from '@/lib/leadModal';

const days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];
const dayFull: Record<string, string> = {
  Пн: 'Понеділок', Вт: 'Вівторок', Ср: 'Середа', Чт: 'Четвер', Пт: 'П\'ятниця', Сб: 'Субота', Нд: 'Неділя',
};
const typeColors: Record<string, string> = {
  'Силові': 'border-neon-300/40 text-neon-300 bg-neon-300/5',
  'Бодібілдинг': 'border-blue-400/40 text-blue-300 bg-blue-400/5',
  'Функціональні': 'border-orange-400/40 text-orange-300 bg-orange-400/5',
};

export default function Schedule() {
  const { open } = useLeadModal();
  const [activeDay, setActiveDay] = useState('Пн');
  const [filter, setFilter] = useState<'all' | 'EGO 1' | 'EGO 2'>('all');

  const filtered = schedule.filter(
    (s) => s.day === activeDay && (filter === 'all' || s.location === filter)
  );

  return (
    <>
      <PageHero
        eyebrow="Розклад"
        title={<>Групові та <span className="neon-text">персональні</span></>}
        subtitle="Обери день та локацію — і приходь на тренування. Попередній запис рекомендований."
      />

      <section className="section-pad">
        <div className="mx-auto max-w-6xl">
          {/* day tabs */}
          <div className="flex flex-wrap gap-2 mb-6 justify-center">
            {days.map((d) => (
              <button
                key={d}
                onClick={() => setActiveDay(d)}
                className={`px-5 py-2.5 rounded-md text-sm font-semibold transition-all ${
                  activeDay === d
                    ? 'bg-neon-300 text-coal-900 shadow-neon-sm'
                    : 'bg-coal-700/60 text-white/70 border border-white/10 hover:border-neon-300/40'
                }`}
              >
                {d}
              </button>
            ))}
          </div>

          {/* location filter */}
          <div className="flex flex-wrap gap-2 mb-8 justify-center">
            {(['all', 'EGO 1', 'EGO 2'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-md text-xs font-medium uppercase tracking-wider transition-all ${
                  filter === f
                    ? 'text-neon-300 neon-border bg-neon-300/5'
                    : 'text-white/50 border border-white/10 hover:text-white/80'
                }`}
              >
                {f === 'all' ? 'Усі локації' : f}
              </button>
            ))}
          </div>

          <h3 className="display-text text-2xl text-white mb-5 text-center tracking-wide">
            {dayFull[activeDay]}
          </h3>

          {filtered.length === 0 ? (
            <div className="text-center py-16 text-white/40">
              На цей день немає занять у вибраній локації.
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {filtered
                .slice()
                .sort((a, b) => a.time.localeCompare(b.time))
                .map((s) => (
                  <div key={s.id} className="card-dark p-5 flex items-center gap-5 group">
                    <div className="shrink-0 flex flex-col items-center justify-center w-16 h-16 rounded-lg bg-coal-900 neon-border">
                      <span className="display-text text-xl neon-text leading-none">{s.time}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-base font-semibold text-white truncate">{s.name}</h4>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-medium border ${typeColors[s.type] || 'border-white/20 text-white/60'}`}>
                          {s.type}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-white/50">
                        <span className="flex items-center gap-1"><User className="w-3.5 h-3.5" /> {s.trainer}</span>
                        <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-neon-300" /> {s.location}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => open('trainer', `Заняття: ${s.name} — ${s.day} ${s.time}, ${s.location}`)}
                      className="shrink-0 btn-outline !px-4 !py-2 text-xs"
                    >
                      Запис
                    </button>
                  </div>
                ))}
            </div>
          )}

          <div className="mt-12 text-center">
            <p className="text-sm text-white/50 mb-4">
              <Clock className="inline w-4 h-4 text-neon-300 mr-1" />
              Тривалість групового заняття — 60 хв. Персонального — 55 хв.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
