import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { PageHero } from '@/components/Section';
import { equipment } from '@/lib/data';
import { useLeadModal } from '@/lib/leadModal';

export default function Equipment() {
  const { open } = useLeadModal();

  return (
    <>
      <PageHero
        eyebrow="Обладнання та зони"
        title={<>Арсенал <span className="neon-text">EGO</span></>}
        subtitle="Професійне обладнання для всіх груп м'язів. Від силових рам до кардіо-зони — все під одним дахом."
      />

      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {equipment.map((e) => (
              <div key={e.id} className="card-dark overflow-hidden group flex flex-col">
                <div className="relative h-60 overflow-hidden">
                  <img
                    src={e.image}
                    alt={e.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-coal-700/90 to-transparent" />
                  <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between">
                    <h3 className="display-text text-2xl text-white tracking-wide">{e.name}</h3>
                    <span className="w-2 h-2 rounded-full bg-neon-300 shadow-neon animate-pulseGlow" />
                  </div>
                </div>
                <div className="p-5 flex flex-col flex-1">
                  <p className="text-sm text-white/60 leading-relaxed mb-4">{e.description}</p>
                  <span className="text-xs text-neon-300/70 uppercase tracking-wider mt-auto">
                    Доступно в EGO 1 та EGO 2
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden border-t border-white/5">
        <div className="absolute inset-0 bg-radial-neon" />
        <div className="relative mx-auto max-w-3xl px-5 sm:px-8 lg:px-12 py-20 text-center">
          <h2 className="display-text text-3xl sm:text-5xl text-white tracking-wide mb-4">
            Хочеш спробувати <span className="neon-text">все це?</span>
          </h2>
          <p className="text-white/60 mb-7">Записуйся на безкоштовне пробне тренування в обраному залі.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => open('trial')} className="btn-neon">Записатися на пробне</button>
            <Link to="/membership" className="btn-outline">Обрати абонемент <ArrowRight className="w-4 h-4" /></Link>
          </div>
        </div>
      </section>
    </>
  );
}
