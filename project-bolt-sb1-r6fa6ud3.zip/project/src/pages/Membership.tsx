import { Check, Star } from 'lucide-react';
import { PageHero } from '@/components/Section';
import { useLeadModal } from '@/lib/leadModal';
import { memberships } from '@/lib/data';

export default function Membership() {
  const { open } = useLeadModal();

  return (
    <>
      <PageHero
        eyebrow="Абонементи"
        title={<>Обери <span className="neon-text">свій темп</span></>}
        subtitle="Прозорі тарифи без прихованих платежів. Розстрочка доступна на довгострокові абонементи."
      >
        <div className="flex flex-wrap justify-center gap-3 text-sm text-white/55">
          {['Без вступних внесків', 'Замороження абонемента', 'Гнучка зміна локації'].map((t) => (
            <span key={t} className="px-4 py-2 rounded-md bg-coal-700/60 border border-white/10">{t}</span>
          ))}
        </div>
      </PageHero>

      <section className="section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
            {memberships.map((m) => (
              <div
                key={m.id}
                className={`relative card-dark p-6 flex flex-col ${
                  m.highlight ? 'border-neon-300/50 shadow-neon lg:scale-[1.03]' : ''
                }`}
              >
                {m.highlight && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-neon-300 text-coal-900 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 shadow-neon">
                    <Star className="w-3 h-3 fill-coal-900" /> Популярний
                  </span>
                )}
                <h3 className="display-text text-2xl text-white mb-1 tracking-wide">{m.name}</h3>
                <p className="text-xs text-white/40 mb-4">{m.period}</p>
                <div className="mb-5">
                  <span className="display-text text-4xl neon-text">{m.price}</span>
                  <span className="text-sm text-white/50"> грн</span>
                </div>
                <ul className="space-y-2.5 mb-6 flex-1">
                  {m.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm text-white/65">
                      <Check className="w-4 h-4 text-neon-300 shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => open('membership', `Абонемент: ${m.name} — ${m.price} грн`)}
                  className={m.highlight ? 'btn-neon w-full !py-2.5 text-sm' : 'btn-outline w-full !py-2.5 text-sm'}
                >
                  Обрати абонемент
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* COMPARISON */}
      <section className="section-pad bg-coal-800/40 border-t border-white/5">
        <div className="mx-auto max-w-5xl">
          <h2 className="display-text text-3xl sm:text-4xl text-white tracking-wide text-center mb-10">
            Що входить у <span className="neon-text">кожен</span> абонемент
          </h2>
          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-coal-700/80">
                  <th className="text-left p-4 font-semibold text-white/80">Можливість</th>
                  {memberships.map((m) => (
                    <th key={m.id} className="p-4 text-center font-semibold text-neon-300 whitespace-nowrap">
                      {m.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {[
                  ['Доступ до залу', [true, true, true, true, true]],
                  ['Роздягалка та шафки', [true, true, true, true, true]],
                  ['Групові заняття', [false, true, true, true, true]],
                  ['Персональні тренування', [false, false, true, true, true]],
                  ['Цілодобовий доступ', [false, false, false, false, true]],
                  ['Гостьові візити', [false, false, false, false, true]],
                  ['Замороження', [false, '7 дн', '14 дн', '30 дн', 'без лім']],
                ].map((row, i) => (
                  <tr key={i} className="hover:bg-white/[0.02]">
                    <td className="p-4 text-white/75">{row[0] as string}</td>
                    {(row[1] as (boolean | string)[]).map((v, j) => (
                      <td key={j} className="p-4 text-center">
                        {v === true ? (
                          <Check className="w-4 h-4 text-neon-300 mx-auto" />
                        ) : v === false ? (
                          <span className="text-white/20">—</span>
                        ) : (
                          <span className="text-neon-300 text-xs font-medium">{v}</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-white/40 text-center mt-5">
            Ціни вказані для нових клієнтів. Для студентів та військових діє знижка 10%.
          </p>
        </div>
      </section>
    </>
  );
}
