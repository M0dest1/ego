export type Location = {
  id: string;
  name: string;
  address: string;
  phone: string;
  lat: number;
  lng: number;
};

export const locations: Location[] = [
  {
    id: 'ego1',
    name: 'EGO 1',
    address: 'просп. Коцюбинського, 43',
    phone: '+380 (98) 222-14-30',
    lat: 49.2331,
    lng: 28.4096,
  },
  {
    id: 'ego2',
    name: 'EGO 2',
    address: 'просп. Коцюбинського, 78',
    phone: '+380 (98) 222-74-30',
    lat: 49.2397,
    lng: 28.4503,
  },
];

export const scheduleHours = [
  { day: 'Пн — Пт', hours: '8:00 — 22:00' },
  { day: 'Субота', hours: '9:00 — 21:00' },
  { day: 'Неділя', hours: '11:00 — 17:00' },
];

export type Membership = {
  id: string;
  name: string;
  price: number;
  period: string;
  features: string[];
  highlight?: boolean;
};

export const memberships: Membership[] = [
  {
    id: 'single',
    name: 'Разовий',
    price: 250,
    period: 'одне відвідування',
    features: ['Доступ до залу на 2 години', 'Роздягалка та шафки', 'Без фіксації часу'],
  },
  {
    id: 'month1',
    name: '1 місяць',
    price: 900,
    period: '30 днів',
    features: ['Безліміт відвідувань', 'Групові заняття', 'Картка доступу', 'Замороження до 7 днів'],
  },
  {
    id: 'month3',
    name: '3 місяці',
    price: 2400,
    period: '90 днів',
    features: ['Безліміт відвідувань', 'Групові заняття', '1 персональне тренування', 'Замороження до 14 днів'],
    highlight: true,
  },
  {
    id: 'month6',
    name: '6 місяців',
    price: 4200,
    period: '180 днів',
    features: ['Безліміт відвідувань', 'Групові заняття', '3 персональні тренування', 'Замороження до 30 днів'],
  },
  {
    id: 'unlimited',
    name: 'Безліміт',
    price: 7200,
    period: '12 місяців',
    features: ['Цілодобовий доступ', 'Групові + персональні', '5 персональних тренувань', 'Гостьові візити', 'Без заморожень'],
  },
];

export type Trainer = {
  id: string;
  name: string;
  role: string;
  experience: string;
  achievements: string[];
  image: string;
};

export const trainers: Trainer[] = [
  {
    id: 't1',
    name: 'Андрій Ковальчук',
    role: 'Силовий тренер',
    experience: '12 років досвіду',
    achievements: ['МСМ з пауерліфтингу', 'Чемпіон України 2021', 'Сертифікований FST-7 інструктор'],
    image: 'https://images.pexels.com/photos/23414745/pexels-photo-23414745.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 't2',
    name: 'Олександр Ткачук',
    role: 'Бодібілдинг',
    experience: '10 років досвіду',
    achievements: ['Чемпіон з бодібілдингу', 'IFBB Pro Card', 'Спеціалізація: мікс місцел'],
    image: 'https://images.pexels.com/photos/29886673/pexels-photo-29886673.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 't3',
    name: 'Денис Мельник',
    role: 'Функціональний тренінг',
    experience: '8 років досвіду',
    achievements: ['CrossFit Level 2', 'Kettlebell Specialist', 'Реабілітація після травм'],
    image: 'https://images.pexels.com/photos/30165254/pexels-photo-30165254.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 't4',
    name: 'Максим Бондаренко',
    role: 'Гіпертрофія',
    experience: '9 років досвіду',
    achievements: ['МС з бодібілдингу', 'Нутриціологія та ЗОЖ', 'Підготовка до змагань'],
    image: 'https://images.pexels.com/photos/10960029/pexels-photo-10960029.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 't5',
    name: 'Ігор Шевченко',
    role: 'Силовий екстрим',
    experience: '11 років досвіду',
    achievements: ['МС з пауерліфтингу', 'Strongman-атлет', 'Техніка важких базових'],
    image: 'https://images.pexels.com/photos/8874437/pexels-photo-8874437.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 't6',
    name: 'Олег Дудник',
    role: 'Кросфіт / меткон',
    experience: '7 років досвіду',
    achievements: ['CrossFit Level 1', 'WOD-програмування', 'Підготовка до Open'],
    image: 'https://images.pexels.com/photos/13460129/pexels-photo-13460129.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
];

export type Equipment = {
  id: string;
  name: string;
  description: string;
  image: string;
};

export const equipment: Equipment[] = [
  {
    id: 'e1',
    name: 'Силові рами',
    description: 'Професійні силові рами з вбудованою безпекою. Присідання, жим, тяга — повний набір базових вправ у комфортних умовах.',
    image: 'https://images.pexels.com/photos/2261481/pexels-photo-2261481.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'e2',
    name: 'Кросовери',
    description: 'Двостовпурні кросовери для ізольованої роботи по всіх групах м\'язів. Регульована висота та кут тяги.',
    image: 'https://images.pexels.com/photos/5327505/pexels-photo-5327505.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'e3',
    name: 'Пек-дек / Бабочка',
    description: 'Тренажер для грудних м\'язів із біомеханічною траєкторією. Максимальне скорочення без навантаження на суглоби.',
    image: 'https://images.pexels.com/photos/5327499/pexels-photo-5327499.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'e4',
    name: 'Гакк-машини',
    description: 'Гакк-присід та жим ногами під кутом. Безпечне навантаження на квадрицепси, сідничні та спину.',
    image: 'https://images.pexels.com/photos/136404/pexels-photo-136404.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'e5',
    name: 'Кардіо-зона',
    description: 'Професійні бігові доріжки, еліпти, велотренажери та гребля. Панорамні вікна та індивідуальні медіа-екрани.',
    image: 'https://images.pexels.com/photos/37887283/pexels-photo-37887283.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'e6',
    name: 'Зона вільних ваг',
    description: 'Повний набір гантелей від 2.5 до 50 кг, штанги, олімпійські диски та-platforms для мертвих тяг.',
    image: 'https://images.pexels.com/photos/11618177/pexels-photo-11618177.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
];

export type ScheduleClass = {
  id: string;
  time: string;
  name: string;
  trainer: string;
  type: string;
  location: string;
  day: string;
};

export const schedule: ScheduleClass[] = [
  { id: 's1', day: 'Пн', time: '09:00', name: 'Силова база', trainer: 'Андрій Ковальчук', type: 'Силові', location: 'EGO 1' },
  { id: 's2', day: 'Пн', time: '18:00', name: 'CrossFit WOD', trainer: 'Олег Дудник', type: 'Функціональні', location: 'EGO 2' },
  { id: 's3', day: 'Пн', time: '19:30', name: 'Гіпертрофія', trainer: 'Максим Бондаренко', type: 'Бодібілдинг', location: 'EGO 1' },
  { id: 's4', day: 'Вт', time: '10:00', name: 'Функціональний тренінг', trainer: 'Денис Мельник', type: 'Функціональні', location: 'EGO 2' },
  { id: 's5', day: 'Вт', time: '18:30', name: 'Пауерліфтинг', trainer: 'Ігор Шевченко', type: 'Силові', location: 'EGO 1' },
  { id: 's6', day: 'Ср', time: '09:00', name: 'Силова база', trainer: 'Андрій Ковальчук', type: 'Силові', location: 'EGO 1' },
  { id: 's7', day: 'Ср', time: '19:00', name: 'Бодібілдинг', trainer: 'Олександр Ткачук', type: 'Бодібілдинг', location: 'EGO 2' },
  { id: 's8', day: 'Чт', time: '11:00', name: 'CrossFit WOD', trainer: 'Олег Дудник', type: 'Функціональні', location: 'EGO 2' },
  { id: 's9', day: 'Чт', time: '18:00', name: 'Реабілітація', trainer: 'Денис Мельник', type: 'Функціональні', location: 'EGO 1' },
  { id: 's10', day: 'Пт', time: '09:30', name: 'Гіпертрофія', trainer: 'Максим Бондаренко', type: 'Бодібілдинг', location: 'EGO 1' },
  { id: 's11', day: 'Пт', time: '19:00', name: 'Strongman', trainer: 'Ігор Шевченко', type: 'Силові', location: 'EGO 2' },
  { id: 's12', day: 'Сб', time: '10:00', name: 'Функціональний тренінг', trainer: 'Денис Мельник', type: 'Функціональні', location: 'EGO 1' },
  { id: 's13', day: 'Сб', time: '12:00', name: 'Бодібілдинг', trainer: 'Олександр Ткачук', type: 'Бодібілдинг', location: 'EGO 2' },
  { id: 's14', day: 'Нд', time: '12:00', name: 'Силова база', trainer: 'Андрій Ковальчук', type: 'Силові', location: 'EGO 1' },
];

export const schoolCourses = [
  {
    id: 'c1',
    name: 'Базовий курс інструктора',
    duration: '3 місяці',
    price: '12 000 грн',
    description: 'Фундаментальні знання анатомії, біомеханіки та програмування тренувань. Практика в залах EGO з першого тижня.',
    topics: ['Анатомія та фізіологія', 'Техніка базових вправ', 'Програмування для новачків', 'Безпека та травмобезпека'],
  },
  {
    id: 'c2',
    name: 'Персональний тренер PRO',
    duration: '5 місяців',
    price: '22 000 грн',
    description: 'Розширений курс з нутриціології, реабілітації, роботи з клієнтами різних рівнів та бізнесу у фітнесі.',
    topics: ['Нутриціологія та ЗОЖ', 'Робота з травмами', 'Клієнтський сервіс', 'Маркетинг особистого бренду', 'Підготовка до змагань'],
    highlight: true,
  },
  {
    id: 'c3',
    name: 'Силовий коуч',
    duration: '4 місяці',
    price: '18 000 грн',
    description: 'Спеціалізація на пауерліфтингу та сильній атлетиці. Методика періодизації та пікової підготовки.',
    topics: ['Періодизація навантажень', 'Техніка важких базових', 'Тестування 1ПМ', 'Підготовка до змагань'],
  },
];
