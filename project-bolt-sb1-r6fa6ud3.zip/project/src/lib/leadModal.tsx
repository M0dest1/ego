import { createContext, useContext, useState, type ReactNode } from 'react';

export type FormType = 'trial' | 'membership' | 'school' | 'trainer';

type LeadModalState = {
  isOpen: boolean;
  formType: FormType;
  note?: string;
  open: (formType: FormType, note?: string) => void;
  close: () => void;
};

const LeadModalContext = createContext<LeadModalState | undefined>(undefined);

export function LeadModalProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [formType, setFormType] = useState<FormType>('trial');
  const [note, setNote] = useState<string | undefined>(undefined);

  const open = (type: FormType, noteText?: string) => {
    setFormType(type);
    setNote(noteText);
    setIsOpen(true);
  };
  const close = () => setIsOpen(false);

  return (
    <LeadModalContext.Provider value={{ isOpen, formType, note, open, close }}>
      {children}
    </LeadModalContext.Provider>
  );
}

export function useLeadModal() {
  const ctx = useContext(LeadModalContext);
  if (!ctx) throw new Error('useLeadModal must be used within LeadModalProvider');
  return ctx;
}
