import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LeadModalProvider } from '@/lib/leadModal';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import About from '@/pages/About';
import Membership from '@/pages/Membership';
import Trainers from '@/pages/Trainers';
import Equipment from '@/pages/Equipment';
import Schedule from '@/pages/Schedule';
import Massage from '@/pages/Massage';
import School from '@/pages/School';
import VeteranSport from '@/pages/VeteranSport';
import Contacts from '@/pages/Contacts';

export default function App() {
  return (
    <LeadModalProvider>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/membership" element={<Membership />} />
            <Route path="/trainers" element={<Trainers />} />
            <Route path="/equipment" element={<Equipment />} />
            <Route path="/schedule" element={<Schedule />} />
            <Route path="/massage" element={<Massage />} />
            <Route path="/school" element={<School />} />
            <Route path="/veteran-sport" element={<VeteranSport />} />
            <Route path="/contacts" element={<Contacts />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </LeadModalProvider>
  );
}
