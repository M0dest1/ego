import { Link } from 'react-router-dom';
import { Dumbbell, MapPin, Phone, Clock, Instagram, Send, Facebook } from 'lucide-react';
import { locations, scheduleHours } from '@/lib/data';

export default function Footer() {
  return (
    <footer className="relative bg-coal-900 border-t border-white/5 mt-auto">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-neon-300/50 to-transparent" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12 py-14">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* brand */}
          <div>
            <Link to="/" className="flex items-center gap-2.5 mb-4">
              <span className="flex items-center justify-center w-9 h-9 rounded-md bg-coal-700 neon-border">
                <Dumbbell className="w-5 h-5 text-neon-300" />
              </span>
              <span className="display-text text-xl tracking-wider">
                <span className="neon-text">EGO</span> <span className="text-white">FITNESS</span>
              </span>
            </Link>
            <p className="text-sm text-white/55 leading-relaxed">
              Професійні зали, сертифіковані тренери, школа інструкторів.
            </p>
            <div className="flex items-center gap-3 mt-5">
              {[
                { icon: Instagram, href: 'https://instagram.com', label: 'Instagram' },
                { icon: Send, href: 'https://t.me', label: 'Telegram' },
                { icon: Facebook, href: 'https://facebook.com', label: 'Facebook' },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex items-center justify-center w-10 h-10 rounded-md border border-white/10 text-white/70 hover:text-neon-300 hover:border-neon-300/50 hover:shadow-neon-sm transition-all"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* navigation */}
          <div>
            <h4 className="display-text text-lg text-white mb-4 tracking-wide">Навігація</h4>
            <ul className="space-y-2.5 text-sm">
              {[
                { to: '/', label: 'Головна' },
                { to: '/about', label: 'Про клуб' },
                { to: '/membership', label: 'Абонементи' },
                { to: '/trainers', label: 'Тренери' },
                { to: '/equipment', label: 'Обладнання' },
                { to: '/schedule', label: 'Розклад' },
                { to: '/school', label: 'Школа тренерів' },
                { to: '/contacts', label: 'Контакти' },
              ].map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="text-white/60 hover:text-neon-300 transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* locations */}
          <div>
            <h4 className="display-text text-lg text-white mb-4 tracking-wide">Локації</h4>
            <ul className="space-y-5">
              {locations.map((l) => (
                <li key={l.id}>
                  <div className="flex items-center gap-2 text-neon-300 font-semibold text-sm mb-1">
                    <MapPin className="w-4 h-4" /> {l.name}
                  </div>
                  <div className="text-sm text-white/60 pl-6">{l.address}</div>
                  <div className="flex items-center gap-2 text-sm text-white/60 pl-6 mt-1">
                    <Phone className="w-3.5 h-3.5" /> {l.phone}
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* hours */}
          <div>
            <h4 className="display-text text-lg text-white mb-4 tracking-wide">Графік роботи</h4>
            <ul className="space-y-2.5 text-sm">
              {scheduleHours.map((s) => (
                <li key={s.day} className="flex items-center justify-between gap-3 text-white/60">
                  <span className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-neon-300/70" /> {s.day}
                  </span>
                  <span className="text-white/80 font-medium">{s.hours}</span>
                </li>
              ))}
            </ul>
            <p className="text-xs text-white/40 mt-4">Графік однаковий для обох залів</p>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-white/40">© {new Date().getFullYear()} EGO Fitness School. Усі права захищені.</p>
          <p className="text-xs text-white/40">
            Створено з <span className="text-neon-300">EGO</span> — сили, волі, результату.
          </p>
        </div>
      </div>
    </footer>
  );
}
