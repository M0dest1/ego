import { lazy, Suspense } from 'react';
import { MapPin } from 'lucide-react';
import { locations } from '@/lib/data';

const LeafletMap = lazy(() => import('./LeafletMap'));

export default function MapView() {
  return (
    <Suspense
      fallback={
        <div className="h-[400px] lg:h-[460px] rounded-xl border border-neon-300/20 bg-coal-700/40 flex items-center justify-center text-white/40 text-sm">
          Завантаження карти…
        </div>
      }
    >
      <LeafletMap locations={locations} />
    </Suspense>
  );
}

export { MapPin };

