import { useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Dumbbell, Phone } from 'lucide-react';
import { useLeadModal } from '@/lib/leadModal';
import { locations } from '@/lib/data';

const navItems = [
  { to: '/', label: 'Головна' },
  { to: '/about', label: 'Про клуб' },
  { to: '/membership', label: 'Абонементи' },
  { to: '/trainers', label: 'Тренери' },
  { to: '/schedule', label: 'Групові тренування' },
  { to: '/massage', label: 'Масаж' },
  { to: '/school', label: 'Школа тренерів' },
  { to: '/veteran-sport', label: 'Ветеранський спорт' },
  { to: '/contacts', label: 'Контакти' },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { open: openModal } = useLeadModal();

  const closeMenu = () => setOpen(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-coal-900/80 backdrop-blur-md border-b border-white/5">
      {/* top strip */}
      <div className="hidden lg:flex items-center justify-center gap-6 py-1.5 text-[11px] text-white/50 border-b border-white/5">
        {locations.map((l) => (
          <span key={l.id} className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-neon-300 animate-pulseGlow" />
            {l.name} — {l.address}
          </span>
        ))}
        <span className="text-white/30">|</span>
        <span className="text-neon-300">Пн-Пт 8:00-22:00 · Сб 9:00-21:00 · Нд 11:00-17:00</span>
      </div>

      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12 flex items-center justify-between h-16 lg:h-[68px]">
        <Link to="/" onClick={closeMenu} className="flex items-center gap-2.5 group shrink-0">
          <span className="relative flex items-center justify-center w-9 h-9 rounded-md bg-coal-700 neon-border group-hover:shadow-neon transition-shadow">
            <Dumbbell className="w-5 h-5 text-neon-300" />
          </span>
          <span className="display-text text-xl sm:text-2xl tracking-wider leading-none">
            <span className="neon-text">EGO</span>{' '}
            <span className="text-white">FITNESS SCHOOL</span>
          </span>
        </Link>

        {/* desktop nav */}
        <nav className="hidden xl:flex items-center gap-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'text-neon-300 bg-neon-300/5'
                    : 'text-white/75 hover:text-neon-300 hover:bg-white/5'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => openModal('trial')}
            className="hidden sm:inline-flex btn-neon !px-5 !py-2.5 text-sm"
          >
            <Phone className="w-4 h-4" />
            Записатись
          </button>
          <button
            onClick={() => setOpen((v) => !v)}
            className="xl:hidden flex items-center justify-center w-10 h-10 rounded-md border border-white/10 text-neon-300 hover:border-neon-300/50 hover:shadow-neon-sm transition-all"
            aria-label="Меню"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* mobile menu */}
      <div
        className={`xl:hidden overflow-hidden transition-all duration-300 ${
          open ? 'max-h-[640px] border-t border-white/5' : 'max-h-0'
        }`}
      >
        <nav className="flex flex-col px-5 py-4 gap-1 bg-coal-800/95">
          {navItems.map((item) => {
            const active = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={closeMenu}
                className={`px-4 py-3 rounded-md text-base font-medium transition-colors ${
                  active ? 'text-neon-300 bg-neon-300/5 neon-border' : 'text-white/85 hover:text-neon-300 hover:bg-white/5'
                }`}
              >
                {item.label}
              </Link>
            );
          })}
          <button
            onClick={() => {
              closeMenu();
              openModal('trial');
            }}
            className="btn-neon mt-2 w-full"
          >
            <Phone className="w-4 h-4" />
            Записатись
          </button>
        </nav>
      </div>
    </header>
  );
}
