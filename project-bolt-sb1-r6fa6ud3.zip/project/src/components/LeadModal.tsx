import { useState, useEffect } from 'react';
import { X, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { useLeadModal, type FormType } from '@/lib/leadModal';
import { locations } from '@/lib/data';
import { supabase } from '@/lib/supabase';

const titles: Record<FormType, string> = {
  trial: 'Запис на пробне тренування',
  membership: 'Оформлення абонемента',
  school: 'Заявка в Школу тренерів',
  trainer: 'Запис до тренера',
};

const submitLabels: Record<FormType, string> = {
  trial: 'Підтвердити запис',
  membership: 'Підтвердити запис',
  school: 'Подати заявку',
  trainer: 'Підтвердити запис',
};

type Status = 'idle' | 'submitting' | 'success' | 'error';

export default function LeadModal() {
  const { isOpen, formType, note, close } = useLeadModal();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [locationId, setLocationId] = useState(locations[0].id);
  const [status, setStatus] = useState<Status>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setStatus('idle');
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    if (isOpen) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, close]);

  const reset = () => {
    setFirstName('');
    setLastName('');
    setPhone('');
    setLocationId(locations[0].id);
    setStatus('idle');
    setErrorMsg('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim() || !lastName.trim() || !phone.trim()) {
      setErrorMsg('Заповніть усі поля');
      setStatus('error');
      return;
    }
    setStatus('submitting');
    setErrorMsg('');

    const loc = locations.find((l) => l.id === locationId);
    const { error } = await supabase.from('leads').insert({
      first_name: firstName.trim(),
      last_name: lastName.trim(),
      phone: phone.trim(),
      location: loc ? loc.name : locationId,
      form_type: formType,
      note: note ?? null,
    });

    if (error) {
      setStatus('error');
      setErrorMsg('Не вдалося надіслати. Спробуйте ще раз.');
      return;
    }
    setStatus('success');
  };

  const handleClose = () => {
    close();
    setTimeout(reset, 300);
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      {/* backdrop */}
      <div
        className="absolute inset-0 bg-coal-900/80 backdrop-blur-sm animate-[floatUp_0.2s_ease-out]"
        onClick={handleClose}
      />

      {/* modal */}
      <div className="relative w-full max-w-md bg-coal-700 border border-neon-300/30 rounded-2xl shadow-neon-lg overflow-hidden animate-floatUp">
        {/* glow top */}
        <div className="h-1 bg-gradient-to-r from-transparent via-neon-300 to-transparent" />

        <div className="p-6 sm:p-8">
          <button
            onClick={handleClose}
            aria-label="Закрити"
            className="absolute top-4 right-4 flex items-center justify-center w-9 h-9 rounded-md text-white/60 hover:text-neon-300 hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {status === 'success' ? (
            <div className="text-center py-6">
              <div className="mx-auto flex items-center justify-center w-16 h-16 rounded-full bg-neon-300/10 neon-border mb-5">
                <CheckCircle2 className="w-8 h-8 text-neon-300" />
              </div>
              <h3 className="display-text text-2xl text-white mb-2">Заявку прийнято!</h3>
              <p className="text-sm text-white/60 mb-6">
                Ми зв'яжемося з вами протягом дня для підтвердження запису.
              </p>
              <button onClick={handleClose} className="btn-outline w-full">
                Закрити
              </button>
            </div>
          ) : (
            <>
              <h3 className="display-text text-2xl text-white tracking-wide mb-1">
                {titles[formType]}
              </h3>
              {note && (
                <p className="text-sm text-neon-300/90 mb-4 bg-neon-300/5 border border-neon-300/20 rounded-md px-3 py-2">
                  {note}
                </p>
              )}
              {!note && <p className="text-sm text-white/50 mb-5">Заповніть форму — ми передзвонимо вам.</p>}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Ім'я">
                    <input
                      type="text"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      placeholder="Іван"
                      className="input-dark"
                    />
                  </Field>
                  <Field label="Прізвище">
                    <input
                      type="text"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      placeholder="Ковальчук"
                      className="input-dark"
                    />
                  </Field>
                </div>
                <Field label="Номер телефону">
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+380 (50) 123-45-67"
                    className="input-dark"
                  />
                </Field>
                <Field label="Локація">
                  <div className="grid grid-cols-2 gap-3">
                    {locations.map((l) => (
                      <button
                        key={l.id}
                        type="button"
                        onClick={() => setLocationId(l.id)}
                        className={`px-4 py-3 rounded-md text-sm font-medium border transition-all ${
                          locationId === l.id
                            ? 'border-neon-300 text-neon-300 bg-neon-300/10 shadow-neon-sm'
                            : 'border-white/10 text-white/70 hover:border-neon-300/40'
                        }`}
                      >
                        {l.name}
                        <span className="block text-[10px] font-normal text-white/40 mt-0.5">
                          {l.address}
                        </span>
                      </button>
                    ))}
                  </div>
                </Field>

                {status === 'error' && (
                  <div className="flex items-center gap-2 text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-md px-3 py-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    {errorMsg}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={status === 'submitting'}
                  className="btn-neon w-full disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {status === 'submitting' ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Відправка...
                    </>
                  ) : (
                    submitLabels[formType]
                  )}
                </button>
                <p className="text-[11px] text-white/35 text-center">
                  Натискаючи кнопку, ви погоджуєтесь на обробку персональних даних.
                </p>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs font-medium text-white/60 mb-1.5 uppercase tracking-wider">
        {label}
      </span>
      {children}
    </label>
  );
}
