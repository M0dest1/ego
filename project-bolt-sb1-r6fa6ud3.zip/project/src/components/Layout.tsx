import { type ReactNode, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import LeadModal from './LeadModal';

export default function Layout({ children }: { children: ReactNode }) {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="flex min-h-screen flex-col bg-coal-900">
      <div className="fixed inset-0 pointer-events-none bg-grid opacity-40" />
      <div className="fixed inset-x-0 top-0 h-[400px] pointer-events-none bg-radial-neon" />
      <Header />
      <main className="relative flex-1 pt-16 lg:pt-[100px]">{children}</main>
      <Footer />
      <LeadModal />
    </div>
  );
}
