import { type ReactNode } from 'react';

export function PageHero({
  eyebrow,
  title,
  subtitle,
  children,
}: {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
  children?: ReactNode;
}) {
  return (
    <section className="relative overflow-hidden border-b border-white/5">
      <div className="absolute inset-0 bg-radial-neon" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8 lg:px-12 py-20 lg:py-28 text-center">
        {eyebrow && (
          <span className="inline-block px-4 py-1.5 mb-5 text-xs font-semibold uppercase tracking-[0.2em] text-neon-300 neon-border rounded-full">
            {eyebrow}
          </span>
        )}
        <h1 className="display-text text-5xl sm:text-6xl lg:text-7xl text-white tracking-wide leading-[1.05]">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-5 mx-auto max-w-2xl text-base sm:text-lg text-white/60 leading-relaxed">
            {subtitle}
          </p>
        )}
        {children && <div className="mt-8">{children}</div>}
      </div>
    </section>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  center = true,
}: {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
  center?: boolean;
}) {
  return (
    <div className={`mb-12 lg:mb-16 ${center ? 'text-center mx-auto max-w-2xl' : 'max-w-2xl'}`}>
      {eyebrow && (
        <span className="inline-block text-xs font-semibold uppercase tracking-[0.25em] text-neon-300 mb-3">
          {eyebrow}
        </span>
      )}
      <h2 className="display-text text-4xl sm:text-5xl text-white tracking-wide leading-[1.1]">
        {title}
      </h2>
      {subtitle && <p className="mt-4 text-white/55 text-base sm:text-lg leading-relaxed">{subtitle}</p>}
    </div>
  );
}
