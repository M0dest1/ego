import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MapPin } from 'lucide-react';
import type { Location } from '@/lib/data';

const neonIcon = L.divIcon({
  className: '',
  html: '<div class="neon-marker" style="width:18px;height:18px"></div>',
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

export default function LeafletMap({ locations }: { locations: Location[] }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRefs = useRef<Record<string, L.Marker>>({});
  const [activeId, setActiveId] = useState(locations[0].id);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [49.2364, 28.43],
      zoom: 13,
      zoomControl: true,
      scrollWheelZoom: false,
    });
    mapRef.current = map;

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap &copy; CARTO',
      maxZoom: 19,
    }).addTo(map);

    locations.forEach((loc) => {
      const marker = L.marker([loc.lat, loc.lng], { icon: neonIcon }).addTo(map);
      marker.bindPopup(
        `<div style="font-family:Inter,sans-serif">
          <div style="color:#39FF14;font-weight:700;font-size:14px;margin-bottom:2px">${loc.name}</div>
          <div style="color:#fff;font-size:13px;opacity:0.85">${loc.address}</div>
          <div style="color:#aaa;font-size:12px;margin-top:4px">${loc.phone}</div>
        </div>`
      );
      markerRefs.current[loc.id] = marker;
    });

    setTimeout(() => map.invalidateSize(), 200);

    return () => {
      map.remove();
      mapRef.current = null;
      markerRefs.current = {};
    };
  }, [locations]);

  const focusLocation = (id: string) => {
    setActiveId(id);
    const loc = locations.find((l) => l.id === id);
    if (!loc || !mapRef.current) return;
    mapRef.current.flyTo([loc.lat, loc.lng], 15, { duration: 0.8 });
    const marker = markerRefs.current[id];
    if (marker) marker.openPopup();
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <div className="space-y-3">
        {locations.map((loc) => {
          const active = activeId === loc.id;
          return (
            <button
              key={loc.id}
              onClick={() => focusLocation(loc.id)}
              className={`w-full text-left p-4 rounded-xl border transition-all ${
                active
                  ? 'border-neon-300/60 bg-neon-300/5 shadow-neon-sm'
                  : 'border-white/10 bg-coal-700/60 hover:border-neon-300/30'
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                <MapPin className={`w-4 h-4 ${active ? 'text-neon-300' : 'text-white/50'}`} />
                <span className={`display-text text-lg tracking-wide ${active ? 'text-neon-300' : 'text-white'}`}>
                  {loc.name}
                </span>
              </div>
              <div className="text-sm text-white/60">{loc.address}</div>
              <div className="text-xs text-white/40 mt-1">{loc.phone}</div>
            </button>
          );
        })}
      </div>

      <div
        ref={containerRef}
        className="h-[400px] lg:h-[460px] rounded-xl overflow-hidden border border-neon-300/20 shadow-neon-sm"
        aria-label="Інтерактивна карта локацій EGO"
      />
    </div>
  );
}
